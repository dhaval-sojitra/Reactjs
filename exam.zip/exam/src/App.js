import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import FetchData from "./components/FetchData";
import Header from "./components/Header";
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path='/' element={<Header title="This is Header" description="About header" />} />
        <Route path='/fetch' element={<FetchData />} />
      </Routes>
    </Router>
  );
}

export default App;
