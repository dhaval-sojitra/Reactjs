import { useRef, useState } from 'react';
import FetchData from './FetchData';

export default function Header({ title }) {
    const [text, setText] = useState('');
    const [display, setDisplay] = useState('');
    // let nameInput = useRef('');

    function changeHandler(e) {
        setText(e.target.value);
    }

    function myFunction() {
        setDisplay(text);
    }


    return (
        <div style={{ display: "flex", justifyContent: "space-between", backgroundColor: "red", height: "100vh" }}>
            <div>
                {/* <h2>{display}</h2> */}
                <form>
                    <label></label>
                    <input type='text' onChange={(e) => changeHandler(e)} />
                    <button type='button' onClick={myFunction}>click</button>
                </form>
            </div>
            <div>
                <h2>{display}</h2>
                <FetchData titla={title} />
            </div>
        </div>
    );
}